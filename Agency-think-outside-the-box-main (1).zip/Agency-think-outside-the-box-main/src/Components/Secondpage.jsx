import React from "react";

const Second =()=>{
    return(
        <>
        <div className="section-2" id="about">
          <div className="sub-head1">
            <h2>Who we are</h2>
            <p>
              Sed ut perspiciatis unde omnis iste natus error sit vo-luptatem
              accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab
              illo inventore veritatis et quasi architecto beatae vitae dicta sunt
              explicabo.
            </p>
            <button className="r-mo2"><a href="">READ MORE</a></button>
          </div>
          <div className="sec-img">
            <div className="bg-img">
              <img src="image/Rectangle 3.png" alt="" />
            </div>
            <img className="mac" src="image/mac.png" alt="" />
          </div>
        </div>
        </>
    )
}
export default Second
